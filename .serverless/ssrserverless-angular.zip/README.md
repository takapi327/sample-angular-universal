# SampleAngularUniversity

## Build ssr

```
$ yarn build:ssr
```

## Run Angular Universal application

```
$ yarn serve:ssr
```

## Deploy

```
$ serverless deploy
```
